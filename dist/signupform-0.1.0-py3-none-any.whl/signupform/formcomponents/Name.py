#!/bin/env/python3
""" Name.py """
class Name:
	_namesAdded = 0
	def __init__(self):
		self.firstName = None
		self.lastName = None
		self.fullName = None
	def getFirstName( self ):
		return self.firstName
	def setFirstName( self, firstName:str ) -> str:
		self.firstName = firstName
	def getLastName( self ):
		return self.lastName
	def setLastName( self, lastName ):
		self.lastName = lastName
	def getFullName( self ):
		return f"{ self.firstName } { self.lastName }"
	def setFullName( self, firstName, lastName ):
		self.fullName = f"{ firstName } { lastName }"
		self._namesAdded += 1
	def inputFirstName(self):
		firstName = str( input( "> enter your first name: " ) )
		self.setFirstName( firstName )
	def inputLastName( self ):
		lastName = str( input( "> enter your last name: " ) )
		self.setLastName( lastName )
	def view(self):
		print( "> your name:", self.getFullName() )