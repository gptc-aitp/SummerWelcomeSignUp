# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['signupform',
 'signupform.datacomponents',
 'signupform.displaycomponents',
 'signupform.formcomponents']

package_data = \
{'': ['*']}

install_requires = \
['inquirer>=3.1.3,<4.0.0']

setup_kwargs = {
    'name': 'signupform',
    'version': '0.1.0',
    'description': '',
    'long_description': "`last modified: 2023 MAY 20`\n\n# SignUpForm\nThis python application is to be used during GPTC's Summer Welcome week. The purpose of the application is to intake student interest and contact information. As of writing, this application runs on a local machine from the command-line.\n\n## Installation\n* Clone the repository\n\t- `cd ~ && gh repo clone gptc-aitp/SummerWelcomeSignUp`\n* change into the directory\n\t- `cd SummerWelcomeSignUp`\n* Install packages\n\t- `pip3 install -r requirements.txt`\n* Run the application\n\t- `python3 src/app.py`\n\n## Design\nThe design of the application follows this pattern:\n* Welcome\n* Input\n\t- First name\n\t- Last name\n\t- Email\n\t- Selected Interests\n* Save Input to .txt file\n\t- `/SignUpForm/dataout/responses.txt`\n\n## Future Work\n* Build a GUI.\n* Connect to database.\n",
    'author': 'jack l',
    'author_email': 'jlester@student.gptc.edu',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
