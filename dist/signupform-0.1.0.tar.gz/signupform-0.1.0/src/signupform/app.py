#!/bin/env/python3
""" app.py """
import os
import time
import formcomponents.Email as Email
import formcomponents.Name as Name
import formcomponents.Title as Title
import formcomponents.Selections as Selections

if __name__ == "__main__":
	entries = 0
	running = True
	title = Title.Title()
	name = Name.Name()
	email = Email.Email()
	selections = Selections.Selections()
	while running:
		title.view()
		print( "entries:", entries )
		name.inputFirstName()
		name.inputLastName()
		email.inputEmailAddress()
		selections.make()
		data.save()
		entries += 1
		if entries >= 100:
			break
		time.sleep(5)
		# os.system("clear")
		break