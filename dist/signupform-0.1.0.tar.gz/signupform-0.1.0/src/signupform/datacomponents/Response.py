
class Response:
	def __init__(self):
		self.response = None
	def get(self):
		return self.response
	def format( self, firstName, lastName, emailAddress, selections):
		formatted = f"{ firstName } {lastName }            { emailAddress }            { selections }"