#!/bin/env/python3
""" Data.py """

class Data:
	def __init__(self):
	def getResponse
	def save(self, destination, *args):
		with open(destination, "a") as source:
			source.write( *args )
	def retrive(self, destination ):
		with open(destination, "r") as source:
			for line in source:
				source.read( line )
		return